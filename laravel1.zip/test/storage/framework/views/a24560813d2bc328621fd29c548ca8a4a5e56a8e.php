

<?php $__env->startSection('content'); ?>
<div class="main-content-inner">
<h1 align="center">Contact Form</h1>
<div class="row">
<div class="col-8 mt-5">
<?php echo Form::open(['url' => 'contact/submit','method'=>'post']); ?>

    <div class="form-group">
     <?php echo e(Form::label('name', 'Name: ')); ?>

     <?php echo e(Form::text('name', '',['class'=>'form-control','placeholder'=>'Enter Name'])); ?>


    </div>
    <div class="form-group">
     <?php echo e(Form::label('email', 'Email: ')); ?>

     <?php echo e(Form::text('name', '',['class'=>'form-control','placeholder'=>'Enter Email'])); ?>


    </div>
    <div class="form-group">
     <?php echo e(Form::label('message', 'Message :')); ?>

     <?php echo e(Form::textarea('message', '',['class'=>'form-control','placeholder'=>'Enter Message'])); ?>


    </div>
    <div>
    <?php echo e(Form::submit('Submit',['class'=>'btn btn-primary'])); ?>

    </div>
<?php echo Form::close(); ?>

</div>
<div class="col-4">
    <div class="well">
        <div class="h3">This is just contact form</div>
    </div>
</div>
</div>


<!-- <form action="contact/submit">
<div class="form-group">
<label for="name">Name</label>
<input type="text" name="name" class="form-control" id="name" placeholder="Name"/>
</div>
<div class="form-group">
<input type="submit" value="Submit" name="submit" class="btn btn-primary">
</div>
</form> -->

</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel1\test\resources\views/contact.blade.php ENDPATH**/ ?>